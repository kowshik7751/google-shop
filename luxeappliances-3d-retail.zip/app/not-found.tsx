'use client';

import Link from 'next/link';
import { Home, ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-white font-sans antialiased" suppressHydrationWarning>
        <div className="min-h-screen bg-slate-950 text-white flex items-center justify-center p-4">
          <div className="max-w-md w-full text-center bg-slate-900 border border-slate-800 rounded-3xl p-8 shadow-2xl space-y-6">
            <div className="w-16 h-16 rounded-2xl bg-orange-600/20 text-orange-400 flex items-center justify-center mx-auto text-2xl font-black">
              404
            </div>
            <div>
              <h1 className="text-2xl font-black">Page Not Found</h1>
              <p className="text-xs text-slate-400 mt-2">
                The page you are looking for does not exist or has been moved.
              </p>
            </div>

            <div className="flex gap-4">
              <Link
                href="/"
                className="flex-1 py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition shadow-lg shadow-blue-600/30"
              >
                <Home className="w-4 h-4" /> Go to Store
              </Link>
              <button
                onClick={() => window.history.back()}
                className="flex-1 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 transition"
              >
                <ArrowLeft className="w-4 h-4" /> Go Back
              </button>
            </div>
          </div>
        </div>
      </body>
    </html>
  );
}
